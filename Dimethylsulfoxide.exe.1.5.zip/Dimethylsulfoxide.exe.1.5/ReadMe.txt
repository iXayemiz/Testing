  ____  _                _   _           _           _  __           _     _                     
 |  _ \(_)_ __ ___   ___| |_| |__  _   _| |___ _   _| |/ _| _____  _(_) __| | ___   _____  _____ 
 | | | | | '_ ` _ \ / _ \ __| '_ \| | | | / __| | | | | |_ / _ \ \/ / |/ _` |/ _ \ / _ \ \/ / _ \
 | |_| | | | | | | |  __/ |_| | | | |_| | \__ \ |_| | |  _| (_) >  <| | (_| |  __/|  __/>  <  __/
 |____/|_|_| |_| |_|\___|\__|_| |_|\__, |_|___/\__,_|_|_|  \___/_/\_\_|\__,_|\___(_)___/_/\_\___|
                                   |___/                      

Virus Name: Dimethylsulfoxide.exe
Creator: iXayemiz
Made In: C++
Made On: July 3rd, 2026
Made Using: Visual Studio Code
Works On: Windows XP, Windows 7, Windows 10, And Windows 11

Dimethylsulfoxide.exe is a dangerous trojan made in C++.
This trojan was made by the creator: iXayemiz.

This trojan will delete important system files, overwrite the MBR (MasterBootRecord), spam GDI effects and also play disturbing sounds.
When you run trojan you will take notice that the creator will NOT be responsible for any damage done caused to you or someone elses real hardware.
You take ALL responsibility when trying to open this.

YOU MUST RUN IN A VIRTUAL MACHINE!!!!!