GDI Malware Made By iXayemiz!!!

This might be the longest and best one i made so far...
This works on: Windows 10 and 11
Made In: C++
run in a vm cuz this is super omega big huge epic destructive so yeah man