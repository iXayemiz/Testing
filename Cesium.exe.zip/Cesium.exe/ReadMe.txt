   ____          _                                
  / ___|___  ___(_)_   _ _ __ ___    _____  _____ 
 | |   / _ \/ __| | | | | '_ ` _ \  / _ \ \/ / _ \
 | |__|  __/\__ \ | |_| | | | | | ||  __/>  <  __/
  \____\___||___/_|\__,_|_| |_| |_(_)___/_/\_\___|
                                                  
Made In: C++
Made With: Visual Studio Code
Created On: July 10, 2026
Finished On: July 13, 2026
Works On: Windows 10 & Windows 11

Note:
YOU MUST RUN ON A VIRTUAL MACHINE!! 
THE CREATOR WILL NOT BE RESPONSIBLE FOR THE DAMAGE OF YOUR OR SOMEONE ELSES ACTUAL HARDWARE!!

NOTE 2:
So like dont be a dumbass and like run on real machine or else ur pc is cooked cuz this is pretty malicious
also, not for people who have epilepsy